<div class="imagepage-footer">
	<div>
		<img src="/images/red-paw.png" class="img-responsive" style="vertical-align: middle;"> &nbsp;<a href="http://www.czarspromise.com">CZAR'S PROMISE WEBSITE</a>
	</div>
	<div class="copyright">
		<p>&copy; {{ date("Y") }}&nbsp;Czar's Promise. &nbsp;All Rights Reserved.</p>
	</div>
</div>
	