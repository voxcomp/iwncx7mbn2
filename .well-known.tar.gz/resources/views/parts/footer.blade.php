<div class="footer">
	<div class="clearfix">
		<hr>
		<div class="col col-sm-6 rteright mobile-center col-sm-push-6">
			<img src="/images/red-paw.png" class="img-responsive" style="vertical-align: middle;"> &nbsp;<a href="http://www.czarspromise.com">CZAR'S PROMISE WEBSITE</a>
		</div>
		<div class="col col-sm-6 mobile-center col-sm-pull-6 copyright">
			<p>&copy; {{ date("Y") }}&nbsp;Czar's Promise. &nbsp;All Rights Reserved.</p>
		</div>
	</div>
</div>