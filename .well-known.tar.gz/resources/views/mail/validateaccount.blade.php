@extends('layouts.mail')

@section('title')
	{{ $title }}
@stop

@section('content')
<p>Thank you for your interest in becoming a Czar's Promise event participant! Please click on the link below to validate your e-mail and activate your account.</p>
@stop

@section('buttontext')
	Click here to validate your account
@stop