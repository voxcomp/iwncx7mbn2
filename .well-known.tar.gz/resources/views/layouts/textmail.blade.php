Czar's Promise

@yield('content')

@if(isset($link) && !empty($link))
	@yield('buttontext')

	{{ $link }}
@endif

The Czar's Promise Team

-------------------------------------------------

Czar's Promise is a 501(c)(3) organization.

Note: This email has been sent from an unmonitored email account.  Please do not respond directly to this email.  If you have questions contact Czar's Promise at https://www.czarspromise.com/contact-us