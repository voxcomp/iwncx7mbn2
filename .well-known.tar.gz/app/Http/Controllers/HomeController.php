<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Cache;
use Illuminate\Http\Request;

use App\Donation;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
	    $events = \App\Event::where("event_date",">",time())->get();
	    	    
	    if($events->count()==1) {
		    $event=$events->first();
		    return \Redirect::route('event.view',[$event->slug]);
	    } else {
	        return view('welcome',compact('events'));
	    }
    }

	public function test() {
		$donation = Donation::where('lname','User')->first();
		
		if(!empty($donation)) {
			dd(strtotime($donation->created_at)>strtotime("3 minutes ago"));
		}
		
		dd($donation);
	}
	
	public function unauthorized() {
		return view('pages.unauthorized');
	}
	
	public function pagePromise() {
		$donations = Donation::where('promise','yes')->where('photo','<>','')->orderBy('id','DESC')->get();
		
		return view('pages.promisewall',compact("donations"));
	}
	public function pagePromiseConfirm() {
		return view('pages.donatepromiseconfirm');
	}
}
